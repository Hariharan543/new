package com.dsrc.dao;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.dsrc.model.Product;

public class HibernateUtil 
{
	public boolean saveProduct(Product product)
	{
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Product.class).buildSessionFactory();
		Session s= sx.openSession();
		Transaction t=s.beginTransaction();
		s.save(product);
		t.commit();
		return true;
	}
}
