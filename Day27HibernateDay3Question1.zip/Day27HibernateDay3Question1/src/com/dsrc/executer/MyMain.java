package com.dsrc.executer;

import com.dsrc.view.MenuScreen;

public class MyMain 
{
		public static void main(String[] args) 
		{
			MenuScreen menu=new MenuScreen();
			menu.showMenu();
			
		}
}
