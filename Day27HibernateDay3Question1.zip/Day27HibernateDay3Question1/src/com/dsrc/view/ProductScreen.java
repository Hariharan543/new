package com.dsrc.view;
import java.util.Scanner;

import com.dsrc.model.Product;
import com.dsrc.service.DataValidator;
import com.dsrc.service.ProductController;
public class ProductScreen 
{
	public int showProductScreen()
	{
			// Add the product Menu..
		Scanner sc=new Scanner(System.in);
		
		System.out.println("PRODUCT MENU");
		System.out.println("--------------");
		System.out.println("1. New Product");
		System.out.println("2. Edit Product");
		System.out.println("3. Delete Product");
		System.out.println("4. List Product");
		System.out.println("5. Search Product");
		System.out.println("6. Exit");
		
		System.out.println("Enter Your Choice:");
		
		int prod=sc.nextInt();
		switch(prod)
		{
		case 1:
			System.out.println("Enter Product ID: ");
			int productid=sc.nextInt();
			System.out.println("Enter Product Name: ");
			String productname=sc.next();
			System.out.println("Enter Product Price: ");
			int productprice=sc.nextInt();
			
			Product product=new Product(productid, productname, productprice);
			DataValidator dv=new DataValidator();
			dv.validateProduct(product);
						
		}
		
		return prod;
	}
}

	