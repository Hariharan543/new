package com.dsrc.service;

import com.dsrc.dao.HibernateUtil;
import com.dsrc.model.Product;
import com.dsrc.view.ProductScreen;

public class DataValidator 
{
	public boolean validateProduct(Product product)
	{
		// Code to call DAO..
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.saveProduct(product);
		if(res)
		{
			System.out.println("Product Added Successfully");
			ProductScreen ps=new ProductScreen();
			ps.showProductScreen();
		}
	
		return res;
	}
}


