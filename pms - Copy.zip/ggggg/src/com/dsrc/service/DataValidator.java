package com.dsrc.service;

import com.dsrc.dao.HibernateUtil;
import com.dsrc.exceptions.ProductException;
import com.dsrc.model.Customer;
import com.dsrc.model.Product;
import com.dsrc.model.Staff;
import com.dsrc.view.ProductScreen;

public class DataValidator 
{
	public boolean validatesaveProduct(Product product) throws ProductException
	{
		// Code to call DAO..
		
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.saveProduct(product);
		if(res)
		{
			System.out.println("Product Added Successfully");
           ProductScreen p=new ProductScreen();
			p.showProductScreen();
		}
		return res;
		
		
	}


		
		
	

	public boolean validateupdateProduct(Product product) {
		// TODO Auto-generated method stub
		
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.updateProduct(product);
		try{
		if(res)
		{
			System.out.println("Product Updated Successfully");
			ProductScreen p=new ProductScreen();
			p.showProductScreen();
		}
		}
		catch(Exception e){
			System.out.println("INVALID ID");
		}
		return res;
		
		
		
	}
	
	
	public boolean validatedeleteProduct(Product product) {
		// TODO Auto-generated method stub
		
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.deleteProduct(product);
		try{
		if(res)
		{
			System.out.println("Product deleted Successfully");
			ProductScreen p=new ProductScreen();
			p.showProductScreen();
		}
		}
		catch(Exception e){
			System.out.println("INVALID ID");
		}
		return res;
		
		
		
	}






	public boolean validatesaveStaff(Staff staff) throws ProductException{
		// TODO Auto-generated method stub
		
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.saveStaff(staff);
		if(res)
		{
			System.out.println("Staff Added Successfully");
           ProductScreen p=new ProductScreen();
			p.showProductScreen();
		}
		return res;
		
		
	}






	public boolean validateupdateStaff(Staff staff) throws ProductException {
		// TODO Auto-generated method stub
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.updateStaff(staff);
		if(res)
		{
			System.out.println("Staff updated Successfully");
           ProductScreen p=new ProductScreen();
			p.showProductScreen();
		}
		return res;
		
		
		
		
	}






	public boolean validatedeleteStaff(Staff s3) throws ProductException {
		// TODO Auto-generated method stub
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.deleteStaff(s3);
		if(res)
		{
			System.out.println("Staff updated Successfully");
           ProductScreen p=new ProductScreen();
			p.showProductScreen();
		}
		return res;        
	}






	public boolean validatesaveCustomer(Customer p) throws ProductException {
		// TODO Auto-generated method stub
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.saveCustomer(p);
		if(res)
		{
			System.out.println("Staff updated Successfully");
           ProductScreen ps=new ProductScreen();
			ps.showProductScreen();
		}
		return res;
	}






	public boolean validateupdateCustomer(Customer p2) throws ProductException {
		// TODO Auto-generated method stub
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.editCustomer(p2);
		if(res)
		{
			System.out.println("Staff updated Successfully");
           ProductScreen ps=new ProductScreen();
			ps.showProductScreen();
		}
		return res;
	}






	public boolean validatedeleteCustomer(Customer p3) throws ProductException 
	{
		// TODO Auto-generated method stub
		HibernateUtil hu=new HibernateUtil();
		boolean res=hu.deleteCustomer(p3);
		if(res)
		{
			System.out.println("Staff updated Successfully");
           ProductScreen ps=new ProductScreen();
			ps.showProductScreen();
		}
		return res;
	}
	}
	
	
	

