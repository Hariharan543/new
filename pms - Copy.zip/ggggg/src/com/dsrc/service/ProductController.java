package com.dsrc.service;

import com.dsrc.exceptions.ProductException;
import com.dsrc.view.CustomerScreen;
import com.dsrc.view.ProductScreen;
import com.dsrc.view.StaffScreen;

public class ProductController
{
		public int productManage() throws ProductException
		{
			ProductScreen ps=new ProductScreen();
			ps.showProductScreen();
			
			return 0;		
			}
		
		public int StaffManage() throws ProductException
		{
			StaffScreen ps=new StaffScreen();
			ps.showStaffScreen();
			return 0;
		}
		
		public int CustomerManage()
		{
			CustomerScreen ps=new CustomerScreen();
			try {
				ps.showCustomerScreen();
			} catch (ProductException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return 0;
		}

		
		
}
