package com.dsrc.dao;

import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.Restrictions;

import com.dsrc.exceptions.ProductException;
import com.dsrc.model.Customer;
import com.dsrc.model.Login;
import com.dsrc.model.Product;
import com.dsrc.model.Staff;
import com.dsrc.view.CustomerScreen;
import com.dsrc.view.LoginScreen;
import com.dsrc.view.MenuScreen;
import com.dsrc.view.ProductScreen;
import com.dsrc.view.StaffScreen;

public class HibernateUtil 
{
	
	ProductScreen ps=new ProductScreen();
	
	CustomerScreen cs=new CustomerScreen();
	
	StaffScreen ss=new StaffScreen();

	
	public boolean checkLogin(String loginId, String password) throws ProductException
	{
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Login.class).buildSessionFactory();
		Session session=sx.openSession();
		Transaction transaction=session.beginTransaction();
		
		  List lst = session.createQuery("FROM Login").list(); 
          for (Iterator iterator = lst.iterator(); iterator.hasNext();){
              Login l = (Login) iterator.next(); 
         {
		if(l.getLoginId().equals(loginId) && l.getPassword().equals(password))
		{
		MenuScreen ms=new MenuScreen();
		ms.showMenu();
		}
         }
 
	}  
          System.out.println("Invalid");
		return true;
		}
	
	
	
 
	public boolean saveProduct(Product product)
	{
		
		SessionFactory sf=new AnnotationConfiguration().configure().addAnnotatedClass(Product.class).buildSessionFactory();
		Session s=sf.openSession();
		Transaction tc=s.beginTransaction();
		s.save(product);
		tc.commit();
		return true;
	}

	
	
	
	
	
	public boolean updateProduct(Product product)
	{
		SessionFactory sf=new AnnotationConfiguration().configure().addAnnotatedClass(Product.class).buildSessionFactory();
		Session s=sf.openSession();
		Transaction tc=s.beginTransaction();
		s.update(product);
		tc.commit();
		return true;
	}
	
	
	
	public boolean deleteProduct(Product product)
	{

//System.out.println(product.getProductid()+"A");
	SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Product.class).buildSessionFactory();
	Session s=sx.openSession();
	Transaction t=s.beginTransaction();
	Product pp=(Product)s.get(Product.class, product.getProductid());
	//System.out.println(pp.getProductid()+"B");
	s.delete(pp);
	t.commit();
	System.out.println("Product deleted Successfully .");
	
	/*String hql = "DELETE FROM Product P WHERE P.productid =:asd";
	
	
	Query q1 = s.createQuery(hql);
	q1.setParameter("asd", product.getProductid());
	int result = q1.executeUpdate();
*/
	
	
	return true;
	
	
}
	
	
	
	public boolean list() throws ProductException
	{
	SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Product.class).buildSessionFactory();
	Session s=sx.openSession();
	Transaction t=s.beginTransaction();
	
	List prolist=s.createQuery("FROM Product").list();
	
	System.out.println("------------------------------------------------");
	System.out.format("%-15s %-15s %-15s %n", "ProductID","Product Name ","Product price" );
	System.out.println("------------------------------------------------");
	for(Iterator i=prolist.iterator();i.hasNext();)
	{
		
		Product pro=(Product) i.next();
		System.out.format("%-15s %-15s %-15s %n", pro.getProductid(),pro.getProductname(),pro.getPrice());
}
	ps.showProductScreen();
	return true;
}
	
	
	
	public boolean searchByID(int id1) throws ProductException
	{
		// TODO Auto-generated method stub
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Product.class).buildSessionFactory();
		Session s=sx.openSession();
		Transaction t=s.beginTransaction();
		String hql1 = "FROM Product P WHERE P.productid=?";
		
		Query q = s.createQuery(hql1);
		q.setInteger(0, id1);
		
		List results = q.list();
		System.out.println("------------------------------------------------");
		System.out.format("%-15s %-15s %-15s %n", "ProductID ",  "Product Name ", " Product price" );
		System.out.println("------------------------------------------------");
		for(Iterator i=results.iterator();i.hasNext();)
		{
			
			Product pro=(Product) i.next();
			System.out.format("%-15s %-15s %-15s %n", pro.getProductid(),pro.getProductname(),pro.getPrice());
	}	
		ps.showProductScreen();
		return true;
	}
	
	
	
	
	
	
	
	public boolean searchByName(String proname) throws ProductException {
		// TODO Auto-generated method stub
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Product.class).buildSessionFactory();
		Session s=sx.openSession();
		Transaction t=s.beginTransaction();
		String hql1 = "FROM Product P WHERE P.productname=?";
		
		Query q = s.createQuery(hql1);
		q.setString(0, proname);
		
		List results = q.list();
		System.out.println("------------------------------------------------");
		System.out.format("%-15s %-15s %-15s %n", "ProductID ",  "Product Name ", " Product price" );
		System.out.println("------------------------------------------------");
		for(Iterator i=results.iterator();i.hasNext();)
		{
			
			Product pro=(Product) i.next();
			System.out.format("%-15s %-15s %-15s %n", pro.getProductid(),pro.getProductname(),pro.getPrice());
	}	
		ps.showProductScreen();

		
		return true;
	}
	
	
	
	
	
	
	
	
	public boolean searchByRange(int fromPrice,int toPrice) throws ProductException
	{
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Product.class).buildSessionFactory();
		Session s=sx.openSession();
		Transaction t=s.beginTransaction();
		String hql3 = "FROM Product P WHERE price between ? and ? ";
		
		Query q3 = s.createQuery(hql3);
	
		q3.setInteger(0, fromPrice);
		q3.setInteger(1, toPrice);
		
		List prolist = q3.list();
		System.out.println("------------------------------------------------");
		System.out.format("%-15s %-15s %-15s %n", "ProductID ",  "Product Name ", " Product price" );
		System.out.println("------------------------------------------------");
		for(Iterator i=prolist.iterator();i.hasNext();)
		{
			
			Product pro=(Product) i.next();
			System.out.format("%-15s %-15s %-15s %n", pro.getProductid(),pro.getProductname(),pro.getPrice());
	}		ps.showProductScreen();

		return true;
	}

	

	
	
	
	
	public boolean saveStaff(Staff staff) throws ProductException
	{
		if(staff.getSalary()>0){
		
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Staff.class).buildSessionFactory();
		Session s=sx.openSession();
		Transaction t=s.beginTransaction();
	
		s.save(staff);	
		t.commit();
		System.out.println("Staff Added Successfully .");
		
		ss.showStaffScreen();
		}
		
		else
		{
			throw new ProductException("Salary can't be Negative");
		}
		return true;
	}

	public boolean updateStaff(Staff p2) throws ProductException {
		// TODO Auto-generated method stub
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Staff.class).buildSessionFactory();
		Session s=sx.openSession();
		Transaction t=s.beginTransaction();
	
		s.saveOrUpdate(p2);	
		t.commit();
		System.out.println("Staff updated Successfully .");
		ss.showStaffScreen();
		
		return true;
		
		
	
	}

	public boolean deleteStaff(Staff staff) throws ProductException {
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Staff.class).buildSessionFactory();
		Session s=sx.openSession();
		String hql = "DELETE FROM Staff P WHERE P.staffid =?";
		Transaction t=s.beginTransaction();
		Staff pp=(Staff)s.get(Staff.class, staff.getStaffid());

		//Query q1 = s.createQuery(hql);

		//q1.setInteger(0, proid);
		//int result = q1.executeUpdate();

		s.delete(pp);
		t.commit();
		System.out.println("Deleted");
		ss.showStaffScreen();

		

		return true;
	}

/*	public boolean updateProduct(Staff staff)
	{
		
		s.save(staff);	
		t.commit();
		System.out.println("Staff updated Successfully .");
		
		ps.showStaffScreen();
		return true;
	}
	
	
*/
	
	
public boolean deleteProduct(int id) throws ProductException
{
	String hql = "DELETE FROM Product P WHERE P.productid =:asd";
	
	SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Staff.class).buildSessionFactory();
	Session s=sx.openSession();
	Transaction t=s.beginTransaction();
	
	Query q1 = s.createQuery(hql);

	q1.setInteger("asd", id);
	int result = q1.executeUpdate();

	
	System.out.println("Deleted");
	ss.showStaffScreen();

	return true;
}
	
	




	
	
	


	
	




	public boolean saveCustomer(Customer p) throws ProductException {
		// TODO Auto-generated method stub
		 String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                 "[a-zA-Z0-9_+&*-]+)*@" + 
                 "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                 "A-Z]{2,7}$"; 
		
		String phoneregex="(0/91)?[7-9][0-9]{9}";
		 String ph=String.valueOf(p.getMobile());
	       // Pattern pattern = Pattern.compile("(0/91)?[7-9][0-9]{9}"); 
	      // Matcher m = pattern.matcher(p.getMobile()); 
		Pattern pat1 = Pattern.compile(phoneregex);            
Pattern pat = Pattern.compile(emailRegex); 
if(p.getCustomerEmail().matches(emailRegex)){
	if(ph.matches(phoneregex)){
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Customer.class).buildSessionFactory();
		Session s=sx.openSession();
		Transaction t=s.beginTransaction();
	
		s.save(p);	
		t.commit();
		System.out.println("Product Added Successfully .");
		cs.showCustomerScreen();
}
	else{
		throw new ProductException("Invalid phone");
	}
	}

else
{
	throw new ProductException("Invalid Email");
	
}
		return true;
		
		

	}


	
	public boolean editCustomer(Customer p) throws ProductException {
		// TODO Auto-generated method stub
		
		
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Customer.class).buildSessionFactory();
		Session s=sx.openSession();
		Transaction t=s.beginTransaction();
	
		s.saveOrUpdate(p);	
		t.commit();
		System.out.println("Customer updated Successfully .");
		cs.showCustomerScreen();
		
		return true;
		
		

	}


	public boolean deleteCustomer(Customer p3) throws ProductException {
		// TODO Auto-generated method stub
		
		
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Customer.class).buildSessionFactory();
		Session s=sx.openSession();
		Transaction t=s.beginTransaction();
		Customer pp=(Customer)s.get(Customer.class, p3.getCustomerID());
		s.delete(pp);
		t.commit();
		System.out.println("Customer deleted Successfully .");
		cs.showCustomerScreen();
		
		return true;
		
		
	}
	
	}
	

