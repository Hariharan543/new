package com.dsrc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Staff")
public class Staff {

	@Id
	@Column(name="staffid")
	private int staffid;
	@Column(name="staffName")
	private String staffName ;
	@Column(name="salary")
	private int salary;
	
	public Staff(int staffid, String staffName, int salary) {
		// TODO Auto-generated constructor stub
		this.staffid=staffid;
		this.staffName=staffName;
		this.salary=salary;
	}
	public Staff( ) {
		// TODO Auto-generated constructor stub
	}
	public int getStaffid() {
		return staffid;
	}
	public void setStaffid(int staffid) {
		this.staffid = staffid;
	}
	public String getStaffName() {
		return staffName;
	}
	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	

}
