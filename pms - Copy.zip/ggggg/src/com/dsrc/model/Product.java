package com.dsrc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product {
	
	@Id
	@Column(name="productid")
	private int productid;
	@Column(name="productname")
	private String productname ;
	@Column(name="price")
	private String price;
	
	public Product(int productid, String productname, String price) {
		// TODO Auto-generated constructor stub
		this.productid=productid;
		this.productname=productname;
		this.price=price;
	}
	public Product() {
		// TODO Auto-generated constructor stub
	}
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}

	
}
