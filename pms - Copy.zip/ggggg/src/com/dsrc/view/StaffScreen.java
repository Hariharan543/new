package com.dsrc.view;

import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.dsrc.dao.HibernateUtil;
import com.dsrc.exceptions.ProductException;
import com.dsrc.model.Product;
import com.dsrc.model.Staff;
import com.dsrc.service.DataValidator;

public class StaffScreen {
	
	public int showStaffScreen() throws ProductException
	{
		MenuScreen ss=new MenuScreen();
	// Show the Menu Here..
	Scanner sc=new Scanner(System.in);

	System.out.println("1. New Staff");
	System.out.println("2.  Edit Staff");
	System.out.println("3. Delete Staff");
	
	System.out.println("Enter your Choice :");
	int choice=sc.nextInt();
	SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Staff.class).buildSessionFactory();
	Session s=sx.openSession();

	
	switch(choice)
	{
	case 1:
		Transaction t=s.beginTransaction();

		//Staff ss=new Staff(staffid1,staffname,salary2);
		System.out.println("Enter Staff ID :");
		int staffid1=sc.nextInt();
		System.out.println("Enter Staff name :");
		String staffname=sc.next();
		System.out.println("Enter Staff salary :");
		int salary2=sc.nextInt();
		
		Staff p=new Staff(staffid1,staffname,salary2);
		//boolean res=new HibernateUtilStaff().saveStaff(p);
		DataValidator dv=new DataValidator();
        dv.validatesaveStaff(p);
			break;
		
	case 2:
		Transaction t2=s.beginTransaction();
		System.out.println("Enter Staff ID :");
		int staffidd=sc.nextInt();
		System.out.println("Enter Staff name :");
		String staffnamee=sc.next();
		System.out.println("Enter Staff salary :");
		int salaryy=sc.nextInt();
		Staff p2=new Staff(staffidd,staffnamee,salaryy);
		DataValidator dv2=new DataValidator();
        dv2.validateupdateStaff(p2);
	break;

		
			
			
	case 3:
		System.out.println("Enter Staff ID :");
		int proid=sc.nextInt();
		Staff s3=new Staff();
	s3.setStaffid(proid);
	DataValidator dv3=new DataValidator();
    dv3.validatedeleteStaff(s3);
	ss.showMenu();
			break;

		
		}
return choice;
	

}
	}
