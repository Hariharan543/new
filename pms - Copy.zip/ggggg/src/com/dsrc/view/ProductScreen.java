package com.dsrc.view;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.dsrc.dao.HibernateUtil;
import com.dsrc.exceptions.ProductException;
import com.dsrc.model.Product;
import com.dsrc.service.DataValidator;

public class ProductScreen 
{
		public int showProductScreen() throws ProductException
		{
			
			MenuScreen m=new MenuScreen();
			// Add the product Menu..
			Scanner sc=new Scanner(System.in);
			System.out.println("Product Menu\n");
			System.out.println("1. New Product");
		System.out.println("2. Edit Product");
		System.out.println("3. Delete Product");
		System.out.println("4. List Product");
		System.out.println("5. Search Product");
		System.out.println("6. Exit");
		
		System.out.println("Enter your Choice :");
		
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			
			System.out.println("Enter Product ID :");
			int ProId=sc.nextInt();
			System.out.println("Enter Product Name :");
			String ProName=sc.next();
			System.out.println("Enter ProductPrice :");
			String ProPrice=sc.next();
			Product p=new Product(ProId,ProName,ProPrice);
			DataValidator dv=new DataValidator();
	        dv.validatesaveProduct(p);
			break;
			
			
		case 2:
			System.out.println("Enter ProductID:");
       	 int a=sc.nextInt();
       	System.out.println("Enter ProductName:");
       	String b=sc.next();
       	System.out.println("Enter ProductPrice:");
       	String c=sc.next();
  
	 Product product=new Product(a,b,c);
   DataValidator dv2=new DataValidator();
   dv2.validateupdateProduct(product);
   

			
			break;
		case 3:
			
			System.out.println("Enter Product ID :");
			int proid=sc.nextInt();
			
			Product p3=new Product();
			p3.setProductid(proid);
			 DataValidator dv3=new DataValidator();
			   dv3.validatedeleteProduct(p3);
			
			break;
		case 4:
			
			
			
			Product p4=new Product();
			boolean res4=new HibernateUtil().list();
			
			break;
		
		case 5:
			
			System.out.println("1. By Product Id");
			System.out.println("2. By Name");
			System.out.println("3. By Price range");
			int select=sc.nextInt();
			switch(select)
			{
			case 1 :
			
			System.out.println("Enter Product ID :");
			int id1=sc.nextInt();
			
			boolean res1=new HibernateUtil().searchByID(id1);
			
				break;
			
			case 2:
				
				System.out.println("Enter Product Name :");
				String proname=sc.next();
				
				boolean ress2=new HibernateUtil().searchByName(proname);

				

				break;
			
			case 3:
				
				System.out.println("Enter From Price");
				int pr1=sc.nextInt();
				System.out.println("Enter To Price");
				int pr2=sc.nextInt();
				boolean ress3=new HibernateUtil().searchByRange(pr1, pr2);
				break;
			}
			
			
			
			break;
			
			
				
		case 6:
			System.out.println(0);
			m.showMenu();
			break;
		}
		return choice;
}
}