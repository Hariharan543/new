package com.dsrc.view;

import java.util.Scanner;

import com.dsrc.dao.HibernateUtil;
import com.dsrc.exceptions.ProductException;
import com.dsrc.model.Login;

public class LoginScreen {

	public boolean showLoginScreen() throws ProductException{

	Scanner sc=new Scanner(System.in);
	System.out.println("LoginId");
	String LoginId=sc.next();
	System.out.println("Password");
	String Password=sc.next();
	
	
	Login l=new Login();
	
	boolean res=new HibernateUtil().checkLogin(LoginId,Password);
	
	return true;
	
	
	}
	
}
