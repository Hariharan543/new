package com.dsrc.view;

import java.util.Scanner;

import com.dsrc.dao.HibernateUtil;
import com.dsrc.exceptions.ProductException;
import com.dsrc.model.Customer;
import com.dsrc.model.Product;
import com.dsrc.service.DataValidator;

public class CustomerScreen {

	public boolean showCustomerScreen() throws ProductException
	{
		// Add the product Menu..
		Scanner sc=new Scanner(System.in);
		System.out.println("CUSTOMER MENU");
		System.out.println("-----------------");
		System.out.println("1. New Customer");
		System.out.println("2. Edit Customer");
		System.out.println("3. Delete Customer");
		System.out.println("4. Exit");

System.out.println("Enter your Choice :");
		MenuScreen m=new MenuScreen();
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			
			System.out.println("Enter Customer ID :");
			int CustomerID=sc.nextInt();
			System.out.println("Enter New Name :");
			String CustomerName=sc.next();
			System.out.println("Enter New Email :");
			String CustomerEmail=sc.next();
			System.out.println("Enter New Mobile :");
			int Mobile=sc.nextInt();
			Customer p=new Customer(CustomerID,CustomerName,CustomerEmail,Mobile);
			DataValidator dv1=new DataValidator();
	        dv1.validatesaveCustomer(p);
			break;
			
		case 2:

			System.out.println("Enter Customer ID :");
			int CustomerID2=sc.nextInt();
			System.out.println("Enter New Name :");
			String CustomerName2=sc.next();
			System.out.println("Enter New Email :");
			String CustomerEmail2=sc.next();
			System.out.println("Enter New Mobile :");
			int Mobile2=sc.nextInt();
			Customer p2=new Customer(CustomerID2,CustomerName2,CustomerEmail2,Mobile2);
			DataValidator dv2=new DataValidator();
	        dv2.validateupdateCustomer(p2);
			break;
			
		case 3:
			
			System.out.println("Enter Customer ID :");
			int CustomerID3=sc.nextInt();
			Customer p3=new Customer();
			p3.setCustomerID(CustomerID3);
			DataValidator dv3=new DataValidator();
	        dv3.validatedeleteCustomer(p3);
			boolean res3=new HibernateUtil().deleteCustomer(p3);
			break;
			
		
		case 4:
			
			System.out.println(0);
			m.showMenu();
			break;
	}
	return true;
	
	
	
	}
	}
