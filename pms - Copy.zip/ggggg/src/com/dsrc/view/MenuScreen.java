package com.dsrc.view;

import java.util.Scanner;

import com.dsrc.exceptions.ProductException;
import com.dsrc.service.ProductController;

public class MenuScreen
{

	public int showMenu() throws ProductException {
	
		// Show the Menu Here..
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Select Your Option");
		System.out.println("1. Product");
		System.out.println("2. Sales");
		System.out.println("3. Staff");
		System.out.println("4. Customer");
		System.out.println("Enter your Choice :");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			ProductController pc1 = new ProductController();
        	pc1.productManage(); 
		break;
		case 2:
			ProductController pc2 = new ProductController();
        	pc2.StaffManage(); 
			break;
			
		case 3:
			ProductController pc3 = new ProductController();
        	pc3.StaffManage(); 
			break;
		case 4:
			CustomerScreen cs=new CustomerScreen();
			cs.showCustomerScreen();
			
		}
		return choice;
		}

}
